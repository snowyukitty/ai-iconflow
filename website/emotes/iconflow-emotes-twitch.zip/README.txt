IconFlow emotes — 55 chat reactions, public domain (CC0 1.0).
https://ai-iconflow.com/emotes/

Twitch: each folder holds the 28, 56 and 112 px PNGs Twitch asks for in one upload.
No attribution and no conditions: upload them, change them, sell what you
make with them. The IconFlow name and mark are not part of the dedication.
