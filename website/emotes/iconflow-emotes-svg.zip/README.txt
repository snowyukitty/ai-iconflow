IconFlow emotes — 24 chat reactions, public domain (CC0 1.0).
https://ai-iconflow.com/emotes/

Editable SVG sources on a 1024 grid. Build platform sizes with
  iconflow build <emote>.svg --targets emote
No attribution and no conditions: upload them, change them, sell what you
make with them. The IconFlow name and mark are not part of the dedication.
